﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calculadora_6A.Libreria
{
   public  class Metodos
    {
       /// <summary>
       /// funcion que envia un saludo
       /// </summary>
       /// <returns></returns>
       public string Saludo()
       {
           return "HOLA MUNDO";
       }
       public float Sumar(float numero1, float numero2)
       {
           var resultado = numero1 + numero2;
           return resultado;
       }
        public float restar (float numero1, float numero2)
        {
            var resultado = numero1 - numero2;
            return resultado;
        }
        public float multiplicar(float numero1, float numero2)
        {
            var resultado = numero1 * numero2;
            return resultado;
        }
        public float dividir(float numero1, float numero2)
        {
            var resultado = numero1 / numero2;
            return resultado;
        }
    }
}
