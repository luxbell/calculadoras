﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Calculadora_6A.Libreria;

namespace Calculadora_6A.Consola
{
    class Program
    {
        static void Main(string[] args)
        {
            Metodos misMetodos = new Metodos();
            Console.WriteLine(misMetodos.Saludo());
            Console.WriteLine(misMetodos.Sumar(5, 34));
            Console.WriteLine(misMetodos.restar(5, 34));
            Console.WriteLine(misMetodos.multiplicar(5, 34));
            Console.WriteLine(misMetodos.dividir(5, 34));
            Console.ReadKey();
        }
    }
}
